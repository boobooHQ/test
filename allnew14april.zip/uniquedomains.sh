# Check if two filenames are provided as arguments
if [ $# -lt 2 ]; then
  echo "Usage: $0 <file1> <file2>"
  exit 1
fi

# Read domain names from file 1
domains1=$(cat "$1" | sort -u)

# Read domain names from file 2
domains2=$(cat "$2" | sort -u)

# Merge domain names and remove duplicates
unique_domains=$(echo -e "${domains1}\n${domains2}" | sort -u)

# Output unique domain names to a new file
echo "${unique_domains}" > unique_domains.txt


#usage : ./unique_domains.sh file1.txt file2.txt
