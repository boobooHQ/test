#!/bin/bash

# Replace "input_file.txt" with the name of your input file
input_file="input_file.txt"

# Use grep to extract lines containing a domain name
# Use awk to extract the second column (the domain name)
# Use sed to remove any leading or trailing whitespace and any quotation marks
grep -Eo '[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' "$input_file" | awk -F ',' '{print $2}' | sed 's/^ *//;s/ *$//;s/^"//;s/"$//'
